# pip install flask
# pip install pymongo
# pip install bson

from app import app
from flask import request, jsonify
from pymongo import MongoClient
from bson.json_util import dumps, loads
from bson.objectid import ObjectId
import json
import ast
from importlib.machinery import SourceFileLoader
from datetime import datetime
from bson import ObjectId
# from flask.json import JSONEncoder

# Custom encoder subclass to handle ObjectId
class JSONEncoderCustom(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return super().default(o)

# Use the custom encoder for the Flask app
app.json_encoder = JSONEncoderCustom

# Connect to MongoDB
client = MongoClient(host="localhost", port=27017)

# Import the utils module
utils = SourceFileLoader('*', './app/utils.py').load_module()
db = client.careerhub
collection = db.jobs

# Homepage
@app.route('/')
def homepage():
    return jsonify({"message": "Welcome to the CareerHub Flask API!"})

# Create a Job Post
@app.route('/create/jobPost', methods=['POST'])
def create_job_post():
    job_data = request.json

    title = job_data.get("title")
    industry_name = job_data.get("industry_info", {}).get("industry_name")

    if not title or not industry_name:
        return jsonify(message="Title and industry are required fields."), 400

    collection.insert_one(job_data)
    return jsonify(message="Job post created successfully!")

# View Job Details (part 1)
@app.route('/search_by_job_id/<job_id>', methods=['GET'])
def view_job_details(job_id):
    job = collection.find_one({"id": int(job_id)})
    if job:
        return jsonify(job)
    else:
        return jsonify(message="Job not found."), 404

# View Job Details (part 2)
@app.route('/update_by_job_title', methods=['PUT'])
def update_job_by_title():
    title = request.json.get("title")
    if not title:
        return jsonify(message="Title is required."), 400

    # Fields to update and their paths in the MongoDB document
    fields_to_update = {
        "description": "description",
        "average_salary": "employment_details.average_salary",
        "location": "company.location"
    }

    # Construct the updates dictionary
    updates = {}
    for field in request.json:
        if field in fields_to_update:
            updates[fields_to_update[field]] = request.json[field]

    if not updates:
        return jsonify(message="No valid updates provided."), 400

    # Find the job by title and apply the updates
    job = collection.find_one_and_update({"title": title}, {"$set": updates})

    if job:
        return jsonify(job)
    else:
        return jsonify(message="Job not found."), 404


# Remove Job Listing
@app.route('/delete_by_job_title', methods=['DELETE'])
def delete_job_by_title():
    title = request.args.get("title")

    if not title:
        return jsonify(message="Title is required."), 400

    result = collection.delete_one({"title": title})
    if result.deleted_count:
        return jsonify(message="Job deleted successfully!")
    else:
        return jsonify(message="Job not found."), 404
    

# Salary Range Query
@app.route('/jobs_by_salary_range', methods=['GET'])
def jobs_by_salary_range():
    min_salary = request.args.get("min_salary", type=int)
    max_salary = request.args.get("max_salary", type=int)

    jobs = list(collection.find({"employment_details.average_salary": {"$gte": min_salary, "$lte": max_salary}}))
    return jsonify(jobs)

# Job Experience Level Query
@app.route('/jobs_by_experience_level', methods=['GET'])
def jobs_by_experience_level():
    experience_level = request.args.get("experience_level")

    # Mapping experience level to years (for simplicity)
    experience_mapping = {
        "Entry Level": (0, 3),
        "Mid Level": (4, 8),
        "Senior Level": (9, 12),
        "Management Level": (13, 20),
        "Tenure Level": (21, 99),        
    }

    min_years, max_years = experience_mapping.get(experience_level, (0, 99))
    jobs = list(collection.find({"years_of_experience": {"$gte": min_years, "$lte": max_years}}))
    return jsonify(jobs)

# Top Companies in an Industry
@app.route('/top_companies_by_industry', methods=['GET'])
def top_companies_by_industry():
    industry = request.args.get("industry")

    # Aggregate job posts by company and count them
    pipeline = [
        {"$match": {"industry_info.industry_name": industry}},
        {"$group": {"_id": "$company.name", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": 10}
    ]

    companies = list(collection.aggregate(pipeline))
    return jsonify(companies)

@app.errorhandler(404)
def page_not_found(e):
    '''Send message to the user if route is not defined.'''

    message = {
        "err":
            {
                "msg": "This route is currently not supported."
            }
    }
    resp = jsonify(message)
    resp.status_code = 404
    return resp